# ifndef RTN1_H
# define RTN1_H
 
double rtn1(const double mean,
	    const double sd,
	    const double low,
	    const double high
	    ) ;

# endif
