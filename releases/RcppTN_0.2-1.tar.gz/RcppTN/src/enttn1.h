# ifndef ENTTN1_HPP
# define ENTTN1_HPP
 
double enttn1(const double mean,
              const double sd,
              const double low,
              const double high
              ) ;

# endif
