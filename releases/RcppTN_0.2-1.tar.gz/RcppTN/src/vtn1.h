# ifndef VTN1_H
# define VTN1_H
 
double vtn1(const double mean,
	    const double sd,
	    const double low,
	    const double high
	    ) ;

# endif
